// uma linha

/*
   Comentar
   Multiplas
   Linhas
*/